//
// Created by User on 19/5/2021.
//

#ifndef ASS3Q5_FACT_H
#define ASS3Q5_FACT_H
/*
 * File:   facturial.h
 * Author: AR
 *
 *
 */

long factorial(int size);

#endif //Assignment3Q5_FACTURIAL_H
