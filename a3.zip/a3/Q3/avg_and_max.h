#ifndef AVG_AND_MAX_H
#define AVG_AND_MAX_H
#include "avg_and_max.h"
double average(double array[], int size);
double max(double array[], int size);
#endif //AVG_AND_MAX_H
